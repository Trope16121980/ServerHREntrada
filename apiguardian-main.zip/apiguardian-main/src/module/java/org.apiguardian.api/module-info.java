module org.apiguardian.api {
  exports org.apiguardian.api;
}
